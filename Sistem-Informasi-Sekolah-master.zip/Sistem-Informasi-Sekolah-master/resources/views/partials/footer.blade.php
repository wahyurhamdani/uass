<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; {{ now()->year }} <div class="bullet"></div> Develop By <a href="https://ankhdigital.com">ANKH Digital</a>
    </div>
    <div class="footer-right">
        2.3.0
    </div>
</footer>
